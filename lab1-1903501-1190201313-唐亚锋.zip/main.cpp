#include <iostream>
#include <fstream>
#include <stdio.h>
#include <windows.h>
#include <process.h>
#include <string.h>
#include <winsock.h>
using namespace std;

#pragma comment(lib,"Ws2_32.lib")
#define MAXSIZE 65507
#define HTTP_PORT 80

struct HttpHeader {
	char method[4];
	char url[1024];
	char host[1024];
	char cookie[1024 * 10];
	HttpHeader() {
		ZeroMemory(this, sizeof(HttpHeader));
	}
};
bool InitSocket();
void ParseHttpHead(char* buffer, HttpHeader* httpHeader);
boolean ParseDate(char* buffer, char* field, char* tempDate);
void makeNewHTTP(char* buffer, char* value);
void makeFilename(char* url, char* filename);
void makeCache(char* buffer, char* url);
void getCache(char* buffer, char* filename);
bool ConnectToServer(SOCKET* serverSocket, char* host);
unsigned int _stdcall ProxyThread(LPVOID lpParameter);
//��������������
SOCKET ProxyServer;
SOCKADDR_IN ProxyServerAddr;
const int ProxyPort = 1000;

bool haveCache = false;
bool needCache = true;

// client 
struct ProxyParam {
	SOCKET clientSocket;
	SOCKET serverSocket;
};

//ininite socket
bool InitSocket() {
	//must ininte socket dll
	WORD wVersionRequested;
	WSADATA wsaData;
	// error tips
	int err; 
	// ensure 2.2 version
	wVersionRequested = MAKEWORD(2, 2); 
	// load dll and socket
	err = WSAStartup(wVersionRequested, &wsaData);
	if (err != 0) {
		//cannot find winsock.dll
		printf("����winsock.dllʧ�ܣ�����%d", WSAGetLastError());
		return false;
	}
	if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2) {
		printf("�����ҵ���ȷ��winsock�汾\n");
		WSACleanup();
		return false;
	}
	ProxyServer = socket(AF_INET, SOCK_STREAM, 0); 
	// create socket
	if (INVALID_SOCKET == ProxyServer) {
		printf("�����׽���ʧ�ܣ��������Ϊ %d\n", WSAGetLastError());
		return false;
	}
	ProxyServerAddr.sin_family = AF_INET;
	ProxyServerAddr.sin_port = htons(ProxyPort); 
	// point to socket port
	ProxyServerAddr.sin_addr.S_un.S_addr = INADDR_ANY;
	if (bind(ProxyServer, (SOCKADDR*)&ProxyServerAddr, sizeof(SOCKADDR)) == SOCKET_ERROR) {
		printf("���׽���ʧ��\n");
		return false;
	}
	if (listen(ProxyServer, SOMAXCONN) == SOCKET_ERROR) {
		printf("�����˿�%dʧ��", ProxyPort);
		return false;
	}
	return true;
}

//parse httpHead in tcp 
void ParseHttpHead(char* buffer, HttpHeader* httpHeader) {
	char* p;
	char* ptr;
	const char* endChar = "\r\n";
	p = strtok_s(buffer, endChar, &ptr);

	if (p[0] == 'G') {
		// Get
		memcpy(httpHeader->method, "GET", 3);
		memcpy(httpHeader->url, &p[4], strlen(p) - 13);  //url�ĳ���, length of("get http/1.1 ")
	}
	else if (p[0] == 'P') {
		// Post
		memcpy(httpHeader->method, "POST", 4);
		//url�ĳ���, length of("post http/1.1 ")
		memcpy(httpHeader->url, &p[5], strlen(p) - 14);
	}

	p = strtok_s(NULL, endChar, &ptr);
	while (p) {
		switch (p[0]) {
		case 'H':  //host
			memcpy(httpHeader->host, &p[6], strlen(p) - 6);
			break;
		case 'C': //cookie
			if (strlen(p) > 8) {
				char header[8];
				ZeroMemory(header, sizeof(header));
				memcpy(header, p, 6);
				if (!strcmp(header, "Cookie")) {
					memcpy(httpHeader->cookie, &p[8], strlen(p) - 8);
				}
			}
			break;
		default:
			break;
		}
		p = strtok_s(NULL, endChar, &ptr);
	}
}

//parsr field in httpHeader, return date
boolean ParseDate(char* buffer, char* field, char* tempDate) {
	char* p, * ptr, temp[5];
	const char* delim = "\r\n";
	ZeroMemory(temp, 5);
	p = strtok_s(buffer, delim, &ptr);
	int len = strlen(field) + 2;
	while (p) {
		if (strstr(p, field) != NULL) {
			memcpy(tempDate, &p[len], strlen(p) - len);
			return true;
		}
		p = strtok_s(NULL, delim, &ptr);
	}
	return false;
}

//����HTTP������
void makeNewHTTP(char* buffer, char* value) {
	const char* field = "Host";
	const char* newfield = "If-Modified-Since: ";
	char temp[MAXSIZE];
	ZeroMemory(temp, MAXSIZE);
	char* pos = strstr(buffer, field);
	for (int i = 0; i < strlen(pos); i++) {
		temp[i] = pos[i];
	}
	*pos = '\0';
	while (*newfield != '\0') { 
		//insert If-Modified-Since
		*pos++ = *newfield++;
	}
	while (*value != '\0') {
		*pos++ = *value++;
	}
	*pos++ = '\r';
	*pos++ = '\n';
	for (int i = 0; i < strlen(temp); i++) {
		*pos++ = temp[i];
	}

}

//using url to create file
void makeFilename(char* url, char* filename) {
	char* p = filename;
	while (*url != '\0') {
		if (*url != '/' && *url != ':' && *url != '.') {
			*p++ = *url;
		}
		url++;
	}
}


// cache maker
void makeCache(char* buffer, char* url) {
	char* p, * ptr, num[10], tempBuffer[MAXSIZE + 1];
	const char* delim = "\r\n";
	ZeroMemory(num, 10);
	ZeroMemory(tempBuffer, MAXSIZE + 1);
	memcpy(tempBuffer, buffer, strlen(buffer));
	p = strtok_s(tempBuffer, delim, &ptr);//��ȡ��һ��
	memcpy(num, &p[9], 3);
	if (strcmp(num, "200") == 0) {  //״̬����200ʱ����
		//printf("url : %s\n", url);
		char filename[100] = { 0 };  // �����ļ���
		makeFilename(url, filename);
		//printf("filename : %s\n", filename);
		FILE* out;
		if (fopen_s(&out, filename, "wb") == 0) {
			fwrite(buffer, sizeof(char), strlen(buffer), out);
			fclose(out);
		}
		printf("\n�����ѻ��棡\n");
	}
}

// get cache, print in cmd!
void getCache(char* buffer, char* filename) {
	char* p, * ptr, num[10], tempBuffer[MAXSIZE + 1];
	const char* delim = "\r\n";
	ZeroMemory(num, 10);
	ZeroMemory(tempBuffer, MAXSIZE + 1);
	memcpy(tempBuffer, buffer, strlen(buffer));
	p = strtok_s(tempBuffer, delim, &ptr);
	memcpy(num, &p[9], 3);
	if (strcmp(num, "304") == 0) { 
		//if status == 304, using cache local
		printf("��ȡ���ػ��棡\n");
		ZeroMemory(buffer, strlen(buffer));
		FILE* in;
		if (fopen_s(&in, filename, "rb") == 0) {
			fread(buffer, sizeof(char), MAXSIZE, in);
			fclose(in);
		}
		needCache = false;
	}
}

//create socket according to dest, make connection
bool ConnectToServer(SOCKET* serverSocket, char* host) {
	SOCKADDR_IN serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(HTTP_PORT); //�����ֽ�˳�� ---> �����ֽ�˳��
	HOSTENT* hostent = gethostbyname(host);
	if (!hostent) {
		return false;
	}
	IN_ADDR inAddr = *((IN_ADDR*)*hostent->h_addr_list);
	serverAddr.sin_addr.S_un.S_addr = inet_addr(inet_ntoa(inAddr));
	*serverSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (*serverSocket == INVALID_SOCKET) {
		return false;
	}
	if (connect(*serverSocket, (SOCKADDR*)&serverAddr, sizeof(serverAddr)) ==
		SOCKET_ERROR) {
		closesocket(*serverSocket);
		return false;
	}
	return true;

}

int main(int argc, TCHAR* argv[]) {
	printf("������������������\n");
	printf("��ʼ��...\n");
	if (!InitSocket()) {
		printf("��������ʼ��ʧ��\n");
		return -1;
	}
	printf("�����������������У����� : %d\n", ProxyPort);
	SOCKET acceptSocket = INVALID_SOCKET;
	ProxyParam* lpProxyParam;
	HANDLE hThread;
	DWORD dwThreadID;
	// loop listening
	while (true) {
		haveCache = false;
		needCache = true;
		acceptSocket = accept(ProxyServer, NULL, NULL);
		lpProxyParam = new ProxyParam;
		if (lpProxyParam == NULL) {
			continue;
		}
		lpProxyParam->clientSocket = acceptSocket;
		hThread = (HANDLE)_beginthreadex(NULL, 0, &ProxyThread, (LPVOID)lpProxyParam, 0, 0);
		CloseHandle(hThread);
		Sleep(200);
	}
	closesocket(ProxyServer);
	WSACleanup();
	return 0;
}

// thread function
unsigned int _stdcall ProxyThread(LPVOID lpParameter) {
	char Buffer[MAXSIZE], fileBuffer[MAXSIZE];
	char* CacheBuffer, * DateBuffer;
	ZeroMemory(Buffer, MAXSIZE);
	SOCKADDR_IN clientAddr;
	int length = sizeof(SOCKADDR_IN);
	int recvSize;
	int ret;
	//accept connection request from client
	recvSize = recv(((ProxyParam*)lpParameter)->clientSocket, Buffer, MAXSIZE, 0);
	if (recvSize <= 0) {
		goto error;
	}
	HttpHeader* httpHeader = new HttpHeader();
	CacheBuffer = new char[recvSize + 1];
	ZeroMemory(CacheBuffer, recvSize + 1);
	memcpy(CacheBuffer, Buffer, recvSize);
	ParseHttpHead(CacheBuffer, httpHeader);

	//����
	DateBuffer = new char[recvSize + 1];
	ZeroMemory(DateBuffer, strlen(Buffer) + 1);
	memcpy(DateBuffer, Buffer, strlen(Buffer) + 1);
	char filename[100];
	ZeroMemory(filename, 100);
	makeFilename(httpHeader->url, filename);
	char* field = "Date";
	char date_str[30];  //�����ֶ�Date��ֵ
	ZeroMemory(date_str, 30);
	ZeroMemory(fileBuffer, MAXSIZE);
	FILE* in;
	if (fopen_s(&in, filename, "rb") == 0) {
		printf("\n�����������ڸ�url������Ӧ���棡\n");
		fread(fileBuffer, sizeof(char), MAXSIZE, in);
		fclose(in);
		ParseDate(fileBuffer, field, date_str);
		printf("date_str: %s\n", date_str);
		makeNewHTTP(Buffer, date_str);
		printf("\n======������������======\n%s\n", Buffer);
		haveCache = true;
		goto success;
	}

	// ��վ���Σ�http://mail.hit.edu.cn/������
	if (strcmp(httpHeader->url, "http://mail.hit.edu.cn/") == 0) {
		printf("\n************************************\n\n");
		printf("����ǰ������վ�ѱ����Σ�\n");
		goto error;
	}

	// ����
	// ����http://today.hit.edu.cn/�᷵��jwts
	
	if (strcmp(httpHeader->url, "http://today.hit.edu.cn/") == 0) {
		printf("\n************************************\n\n");
		printf("����ɹ�������ǰ����http://today.hit.edu.cn/�ѱ�������http://jwts.hit.edu.cn\n");
		memcpy(httpHeader->host, "jwts.hit.edu.cn", 22);
	}

	//�û�����
	char hostname[128];
	int retnew = gethostname(hostname, sizeof(hostname));
	HOSTENT *hent = gethostbyname(hostname);
	char *ip = inet_ntoa(*(in_addr*)*hent->h_addr_list);  //��ȡ����ip��ַ
	// edge��host��Ĭ��Ϊlx.pub��ʵ��ʱ��edge��jwts���ɡ�
	if (strcmp(httpHeader->host, "lx.pub") == 0) {
		printf("\n=====================================\n\n");
		printf("�ͻ�ip��ַ��%s\n", httpHeader->host);
		printf("���������ѱ����Σ�\n");
		goto error;
	}

	delete CacheBuffer;
	delete DateBuffer;

success:
	if (!ConnectToServer(&((ProxyParam*)lpParameter)->serverSocket, httpHeader->host)) {
		printf("������������ʧ��!\n");
		goto error;
	}
	printf("\n\n------*-*------*-*------*-*------*-*------*-*------*-*------*-*------\n\n");
	printf("������������ %s �ɹ�!\n", httpHeader->host);
	printf("\n======������======\n%s\n", Buffer);
	//directly send client data to serve
	ret = send(((ProxyParam*)lpParameter)->serverSocket, Buffer, strlen(Buffer) + 1, 0);
	//wait serve return
	recvSize = recv(((ProxyParam*)lpParameter)->serverSocket, Buffer, MAXSIZE, 0);
	if (recvSize <= 0) {
		printf("�������ݱ���ʧ��!\n");
		goto error;
	}
	//if 304, return local cache
	if (haveCache == true) {
		getCache(Buffer, filename);
	}
	//return serve info to client directly
	printf("\n======��Ӧ����======\n%s\n", Buffer);
	if (needCache == true) {
		makeCache(Buffer, httpHeader->url);
	}
	ret = send(((ProxyParam*)lpParameter)->clientSocket, Buffer, sizeof(Buffer), 0);

error:  
	Sleep(200);
	closesocket(((ProxyParam*)lpParameter)->clientSocket);
	closesocket(((ProxyParam*)lpParameter)->serverSocket);
	delete lpParameter;
	_endthreadex(0);
	return 0;
}
