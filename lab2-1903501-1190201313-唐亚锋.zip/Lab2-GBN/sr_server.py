import threading
import SR_Protocol


'''用于测试时SR Server端'''
server_sr = SR_Protocol.SRServer()
receive_thread_sr = threading.Thread(target=server_sr.begin_receive)
send_thread_sr = threading.Thread(target=server_sr.begin_send)
receive_thread_sr.start()
send_thread_sr.start()

